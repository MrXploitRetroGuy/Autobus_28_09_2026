public class Autobus
{
   private String kennzeichen;
   private int sitzplatz;
   private boolean anhänger;
   
   public String getKennzeichen()
   {
     return kennzeichen;
   }
    
   public int getSitzplatz()
   {
     return sitzplatz;
   }
    
   public boolean getAnhänger()
   {
     return anhänger;
   }
   
   
   public void setKennzeichen(String neuKennzeichen)
   {
     kennzeichen = neuKennzeichen;
   }
   
   public void setSitzplatz(int neuSitzplatz)
   {
     sitzplatz = neuSitzplatz;
   }
   
   public void setAnhänger(boolean neuAnhänger)
   {
     anhänger = neuAnhänger;
   }
   
   public Autobus(String neuKennzeichen, int neuSitzplatz, boolean neuAnhänger)
   {
     setKennzeichen(neuKennzeichen);
     setSitzplatz(neuSitzplatz);
     setAnhänger(neuAnhänger);
   }
   
   public Autobus(int neuSitzplatz, boolean neuAnhänger)
   {
     setKennzeichen("W-1234A");
     setSitzplatz(neuSitzplatz);
     setAnhänger(neuAnhänger);
   }
   
   public Autobus(boolean neuAnhänger)
   {
     setKennzeichen("W-1234A");
     setSitzplatz(29);
     setAnhänger(neuAnhänger);
   }
   
   public Autobus()
   {
     setKennzeichen("W-1234A");
     setSitzplatz(29);
     setAnhänger(false);
   }
}
